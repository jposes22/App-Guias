package es.server.java.baronha.model.guia.impl;

import es.server.java.baronha.model.generic.impl.DaoBaseImpl;
import es.server.java.baronha.model.guia.GuiaDAO;
import es.server.java.baronha.model.vo.GuiaVO;

public class GuiaDAOImpl extends DaoBaseImpl<GuiaVO> implements GuiaDAO  {

}
