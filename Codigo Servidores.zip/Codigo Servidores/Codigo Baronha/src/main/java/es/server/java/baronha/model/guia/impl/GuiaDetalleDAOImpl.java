package es.server.java.baronha.model.guia.impl;

import es.server.java.baronha.model.generic.impl.DaoBaseImpl;
import es.server.java.baronha.model.guia.GuiaDetalleDAO;
import es.server.java.baronha.model.vo.GuiaDetalleVO;

public class GuiaDetalleDAOImpl extends DaoBaseImpl<GuiaDetalleVO> implements GuiaDetalleDAO {

}
