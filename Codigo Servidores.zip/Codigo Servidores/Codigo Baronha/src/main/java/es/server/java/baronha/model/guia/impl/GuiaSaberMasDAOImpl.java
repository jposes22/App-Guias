package es.server.java.baronha.model.guia.impl;

import es.server.java.baronha.model.generic.impl.DaoBaseImpl;
import es.server.java.baronha.model.guia.GuiaSaberMasDAO;
import es.server.java.baronha.model.vo.GuiaSaberMasVO;

public class GuiaSaberMasDAOImpl extends DaoBaseImpl<GuiaSaberMasVO> implements GuiaSaberMasDAO{

}
