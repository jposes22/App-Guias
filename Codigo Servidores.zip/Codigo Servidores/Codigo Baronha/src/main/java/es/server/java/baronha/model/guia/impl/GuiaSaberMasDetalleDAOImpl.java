package es.server.java.baronha.model.guia.impl;

import es.server.java.baronha.model.generic.impl.DaoBaseImpl;
import es.server.java.baronha.model.guia.GuiaSaberMasDetalleDAO;
import es.server.java.baronha.model.vo.GuiaSaberMasDetalleVO;

public class GuiaSaberMasDetalleDAOImpl extends DaoBaseImpl<GuiaSaberMasDetalleVO> implements GuiaSaberMasDetalleDAO {

}
