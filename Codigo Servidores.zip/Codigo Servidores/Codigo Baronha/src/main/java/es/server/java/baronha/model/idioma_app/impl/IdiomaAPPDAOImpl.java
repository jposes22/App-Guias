package es.server.java.baronha.model.idioma_app.impl;

import es.server.java.baronha.model.generic.impl.DaoBaseImpl;
import es.server.java.baronha.model.idioma_app.IdiomaAPPDAO;
import es.server.java.baronha.model.vo.IdiomaAPPVO;

public class IdiomaAPPDAOImpl extends DaoBaseImpl<IdiomaAPPVO> implements IdiomaAPPDAO{

}
