package es.server.java.baronha.model.menu.impl;

import es.server.java.baronha.model.generic.impl.DaoBaseImpl;
import es.server.java.baronha.model.menu.MenuDAO;
import es.server.java.baronha.model.vo.MenuVO;

public class MenuDAOImpl extends DaoBaseImpl<MenuVO> implements MenuDAO  {
	
}
