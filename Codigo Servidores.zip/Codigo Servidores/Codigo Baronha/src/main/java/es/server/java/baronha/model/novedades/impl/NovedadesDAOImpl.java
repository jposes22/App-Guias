package es.server.java.baronha.model.novedades.impl;


import es.server.java.baronha.model.generic.impl.DaoBaseImpl;
import es.server.java.baronha.model.novedades.NovedadesDAO;
import es.server.java.baronha.model.vo.NovedadVO;

public class NovedadesDAOImpl extends DaoBaseImpl<NovedadVO> implements NovedadesDAO {


}
