package es.server.java.baronha.model.parametros_app.impl;

import es.server.java.baronha.model.generic.impl.DaoBaseImpl;
import es.server.java.baronha.model.parametros_app.ParametrosAPPDAO;
import es.server.java.baronha.model.vo.ParametroAPPVO;

public class ParametrosAPPDAOImpl extends DaoBaseImpl<ParametroAPPVO> implements ParametrosAPPDAO  {

}
