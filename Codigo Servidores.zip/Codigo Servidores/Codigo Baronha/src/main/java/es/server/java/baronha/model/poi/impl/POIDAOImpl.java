package es.server.java.baronha.model.poi.impl;

import es.server.java.baronha.model.generic.impl.DaoBaseImpl;
import es.server.java.baronha.model.poi.POIDAO;
import es.server.java.baronha.model.vo.POIVO;

public class POIDAOImpl extends DaoBaseImpl<POIVO> implements POIDAO  {
	
}
