package es.server.java.borneiro.model.guia.impl;

import es.server.java.borneiro.model.generic.impl.DaoBaseImpl;
import es.server.java.borneiro.model.guia.GuiaDAO;
import es.server.java.borneiro.model.vo.GuiaVO;

public class GuiaDAOImpl extends DaoBaseImpl<GuiaVO> implements GuiaDAO  {

}
