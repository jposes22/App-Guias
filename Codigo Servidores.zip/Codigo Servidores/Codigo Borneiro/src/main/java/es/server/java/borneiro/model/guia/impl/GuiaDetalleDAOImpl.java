package es.server.java.borneiro.model.guia.impl;

import es.server.java.borneiro.model.generic.impl.DaoBaseImpl;
import es.server.java.borneiro.model.guia.GuiaDetalleDAO;
import es.server.java.borneiro.model.vo.GuiaDetalleVO;

public class GuiaDetalleDAOImpl extends DaoBaseImpl<GuiaDetalleVO> implements GuiaDetalleDAO {

}
