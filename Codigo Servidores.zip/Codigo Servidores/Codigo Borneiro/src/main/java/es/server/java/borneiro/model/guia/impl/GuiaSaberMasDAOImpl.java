package es.server.java.borneiro.model.guia.impl;

import es.server.java.borneiro.model.generic.impl.DaoBaseImpl;
import es.server.java.borneiro.model.guia.GuiaSaberMasDAO;
import es.server.java.borneiro.model.vo.GuiaSaberMasVO;

public class GuiaSaberMasDAOImpl extends DaoBaseImpl<GuiaSaberMasVO> implements GuiaSaberMasDAO{

}
