package es.server.java.borneiro.model.guia.impl;

import es.server.java.borneiro.model.generic.impl.DaoBaseImpl;
import es.server.java.borneiro.model.guia.GuiaSaberMasDetalleDAO;
import es.server.java.borneiro.model.vo.GuiaSaberMasDetalleVO;

public class GuiaSaberMasDetalleDAOImpl extends DaoBaseImpl<GuiaSaberMasDetalleVO> implements GuiaSaberMasDetalleDAO {

}
