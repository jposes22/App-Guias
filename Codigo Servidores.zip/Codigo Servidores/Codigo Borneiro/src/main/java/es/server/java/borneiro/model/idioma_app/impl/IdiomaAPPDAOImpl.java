package es.server.java.borneiro.model.idioma_app.impl;

import es.server.java.borneiro.model.generic.impl.DaoBaseImpl;
import es.server.java.borneiro.model.idioma_app.IdiomaAPPDAO;
import es.server.java.borneiro.model.vo.IdiomaAPPVO;

public class IdiomaAPPDAOImpl extends DaoBaseImpl<IdiomaAPPVO> implements IdiomaAPPDAO{

}
