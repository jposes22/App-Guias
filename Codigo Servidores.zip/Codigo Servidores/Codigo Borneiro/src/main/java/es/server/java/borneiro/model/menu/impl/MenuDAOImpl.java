package es.server.java.borneiro.model.menu.impl;

import es.server.java.borneiro.model.generic.impl.DaoBaseImpl;
import es.server.java.borneiro.model.menu.MenuDAO;
import es.server.java.borneiro.model.vo.MenuVO;

public class MenuDAOImpl extends DaoBaseImpl<MenuVO> implements MenuDAO  {
	
}
