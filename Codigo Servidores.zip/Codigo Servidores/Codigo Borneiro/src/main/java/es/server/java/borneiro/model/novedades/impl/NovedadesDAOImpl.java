package es.server.java.borneiro.model.novedades.impl;


import es.server.java.borneiro.model.generic.impl.DaoBaseImpl;
import es.server.java.borneiro.model.novedades.NovedadesDAO;
import es.server.java.borneiro.model.vo.NovedadVO;

public class NovedadesDAOImpl extends DaoBaseImpl<NovedadVO> implements NovedadesDAO {


}
