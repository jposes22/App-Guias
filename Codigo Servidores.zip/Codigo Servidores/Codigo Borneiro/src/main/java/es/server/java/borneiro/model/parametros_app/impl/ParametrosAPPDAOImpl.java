package es.server.java.borneiro.model.parametros_app.impl;

import es.server.java.borneiro.model.generic.impl.DaoBaseImpl;
import es.server.java.borneiro.model.parametros_app.ParametrosAPPDAO;
import es.server.java.borneiro.model.vo.ParametroAPPVO;

public class ParametrosAPPDAOImpl extends DaoBaseImpl<ParametroAPPVO> implements ParametrosAPPDAO  {

}
