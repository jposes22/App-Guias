package es.server.java.borneiro.model.poi.impl;

import es.server.java.borneiro.model.generic.impl.DaoBaseImpl;
import es.server.java.borneiro.model.poi.POIDAO;
import es.server.java.borneiro.model.vo.POIVO;

public class POIDAOImpl extends DaoBaseImpl<POIVO> implements POIDAO  {
	
}
