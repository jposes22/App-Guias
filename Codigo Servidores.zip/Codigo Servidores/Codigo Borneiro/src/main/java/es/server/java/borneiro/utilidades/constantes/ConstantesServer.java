package es.server.java.borneiro.utilidades.constantes;

public class ConstantesServer {

	public static final String URL_IMAGES_APP = "/var/lib/openshift/572611487628e17a9b00015b/jbossews/images/";
	public static final String URL_IMAGES_APP_LOCAL = "C:\\xampp\\tomcat\\ContenidosBorneiro\\";
	public static final String URL_SERVER = "http://95.123.56.172:8080/BORNEIRO/rest/WSImages/getImage/";
	public static final String URL_SERVER_AUDIO_GUIA = "http://95.123.56.172:8080/BORNEIRO/rest/WSAudioGuia/getAudio/";
}
