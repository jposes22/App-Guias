package es.server.java.torres_oeste.model.guia.impl;

import es.server.java.torres_oeste.model.generic.impl.DaoBaseImpl;
import es.server.java.torres_oeste.model.guia.GuiaDAO;
import es.server.java.torres_oeste.model.vo.GuiaVO;

public class GuiaDAOImpl extends DaoBaseImpl<GuiaVO> implements GuiaDAO  {

}
