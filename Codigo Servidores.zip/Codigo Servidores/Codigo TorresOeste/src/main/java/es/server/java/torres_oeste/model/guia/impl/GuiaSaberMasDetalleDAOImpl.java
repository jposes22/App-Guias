package es.server.java.torres_oeste.model.guia.impl;

import es.server.java.torres_oeste.model.generic.impl.DaoBaseImpl;
import es.server.java.torres_oeste.model.guia.GuiaSaberMasDetalleDAO;
import es.server.java.torres_oeste.model.vo.GuiaSaberMasDetalleVO;

public class GuiaSaberMasDetalleDAOImpl extends DaoBaseImpl<GuiaSaberMasDetalleVO> implements GuiaSaberMasDetalleDAO {

}
