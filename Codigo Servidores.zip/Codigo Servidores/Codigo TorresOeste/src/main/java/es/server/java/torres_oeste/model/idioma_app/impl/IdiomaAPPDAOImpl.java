package es.server.java.torres_oeste.model.idioma_app.impl;

import es.server.java.torres_oeste.model.generic.impl.DaoBaseImpl;
import es.server.java.torres_oeste.model.idioma_app.IdiomaAPPDAO;
import es.server.java.torres_oeste.model.vo.IdiomaAPPVO;

public class IdiomaAPPDAOImpl extends DaoBaseImpl<IdiomaAPPVO> implements IdiomaAPPDAO{

}
