package es.server.java.torres_oeste.model.menu.impl;

import es.server.java.torres_oeste.model.generic.impl.DaoBaseImpl;
import es.server.java.torres_oeste.model.menu.MenuDAO;
import es.server.java.torres_oeste.model.vo.MenuVO;

public class MenuDAOImpl extends DaoBaseImpl<MenuVO> implements MenuDAO  {
	
}
