package es.server.java.torres_oeste.model.novedades.impl;


import es.server.java.torres_oeste.model.generic.impl.DaoBaseImpl;
import es.server.java.torres_oeste.model.novedades.NovedadesDAO;
import es.server.java.torres_oeste.model.vo.NovedadVO;

public class NovedadesDAOImpl extends DaoBaseImpl<NovedadVO> implements NovedadesDAO {


}
