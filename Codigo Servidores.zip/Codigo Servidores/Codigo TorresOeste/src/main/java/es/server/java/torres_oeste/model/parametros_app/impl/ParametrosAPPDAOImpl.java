package es.server.java.torres_oeste.model.parametros_app.impl;

import es.server.java.torres_oeste.model.generic.impl.DaoBaseImpl;
import es.server.java.torres_oeste.model.parametros_app.ParametrosAPPDAO;
import es.server.java.torres_oeste.model.vo.ParametroAPPVO;

public class ParametrosAPPDAOImpl extends DaoBaseImpl<ParametroAPPVO> implements ParametrosAPPDAO  {

}
