package es.server.java.torres_oeste.model.poi.impl;

import es.server.java.torres_oeste.model.generic.impl.DaoBaseImpl;
import es.server.java.torres_oeste.model.poi.POIDAO;
import es.server.java.torres_oeste.model.vo.POIVO;

public class POIDAOImpl extends DaoBaseImpl<POIVO> implements POIDAO  {
	
}
