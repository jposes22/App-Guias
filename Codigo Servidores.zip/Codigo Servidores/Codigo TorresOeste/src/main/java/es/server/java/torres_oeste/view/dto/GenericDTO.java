package es.server.java.torres_oeste.view.dto;



public class GenericDTO {

	private Boolean isActivo;
	private long fechaActualizacion;
	
	
	public Boolean getIsActivo() {
		return isActivo;
	}
	public void setIsActivo(Boolean isActivo) {
		this.isActivo = isActivo;
	}
	public long getFechaActualizacion() {
		return fechaActualizacion;
	}
	public void setFechaActualizacion(long fechaActualizacion) {
		this.fechaActualizacion = fechaActualizacion;
	}
	
	
	
}
