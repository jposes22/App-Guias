//
//  HeaderCopyright.h
//  TorresDeOeste
//
//  Created by Evelb on 28/10/16.
//  Copyright © 2016 Evelb. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HeaderCopyright : UIView
- (void) loadData:(NSString *)titulo;
@end
