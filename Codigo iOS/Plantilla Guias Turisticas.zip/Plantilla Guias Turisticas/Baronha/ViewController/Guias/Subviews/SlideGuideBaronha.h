//
//  SlideGuide.h
//  TorresDeOeste
//
//  Created by Evelb on 15/10/16.
//  Copyright © 2016 Evelb. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "GuiaList.h"

@interface SlideGuideBaronha : UIViewController
@property (nonatomic) NSInteger index;
@property (nonatomic, strong) GuiaList * guiaList;


@end
