//
//  CellGuiaDetalleSinImagen.h
//  TorresDeOeste
//
//  Created by Evelb on 23/10/16.
//  Copyright © 2016 Evelb. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "GuiaDetalleList.h"

@interface CellGuiaDetalleSinImagen : UITableViewCell
- (void)loadData:(GuiaDetalleList *)guiaDetalle;
@end
