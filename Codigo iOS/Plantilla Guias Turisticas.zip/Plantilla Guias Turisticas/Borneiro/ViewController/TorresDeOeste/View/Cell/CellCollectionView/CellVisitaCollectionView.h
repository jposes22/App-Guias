//
//  CellVisitaCollectionView.h
//  Plantilla Guias Turisticas
//
//  Created by Evelb on 29/10/16.
//  Copyright © 2016 Evelb. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CellVisitaCollectionView : UICollectionViewCell
@property (weak, nonatomic) IBOutlet UIImageView *imageViewIndex;

@end
