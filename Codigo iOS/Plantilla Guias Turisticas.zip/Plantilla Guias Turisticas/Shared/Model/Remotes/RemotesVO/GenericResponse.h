//
//  GenericResponse.h
//  TorresDeOeste
//
//  Created by Evelb on 11/10/16.
//  Copyright © 2016 Evelb. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface GenericResponse : NSObject

@property (nonatomic, strong) NSNumber *dateFrom;
@property (nonatomic, strong) NSNumber *dateTo;
@property (nonatomic, strong) NSMutableArray *answere;


@end
