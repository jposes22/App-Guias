//
//  RemoteGuiaSaberMasDetalleImagenVO.h
//  TorresDeOeste
//
//  Created by Jose Pose on 21/10/16.
//  Copyright © 2016 Evelb. All rights reserved.
//

#import "GenericResponse.h"

@interface RemoteGuiaSaberMasDetalleImagenVO : GenericResponse
-(RemoteGuiaSaberMasDetalleImagenVO *)initGuiaSaberMasDetalleImagen:(id) jsonObject;

@end
