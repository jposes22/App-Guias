//
//  ViewImage.h
//  TorresDeOeste
//
//  Created by Evelb on 24/10/16.
//  Copyright © 2016 Evelb. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewImage : UIViewController
@property (nonatomic, strong) NSString * imageShow;
@property (nonatomic) NSInteger index;

@end
