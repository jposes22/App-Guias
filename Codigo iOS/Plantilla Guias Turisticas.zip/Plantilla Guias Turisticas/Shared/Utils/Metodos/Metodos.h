//
//  Metodos.h
//  TorresDeOeste
//
//  Created by Evelb on 22/10/16.
//  Copyright © 2016 Evelb. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface Metodos : NSObject
+(NSAttributedString *) convertHTMLToString:(NSString *)textHtml;

@end
