//
//  Constants.m
//  TorresDeOeste
//
//  Created by Evelb on 8/10/16.
//  Copyright © 2016 Evelb. All rights reserved.
//

#import "ConstantsURL.h"

@implementation ConstantsURL


///URL

NSString * const kURL_SERVICE = @"http://95.123.56.172:8080/TORRES_OESTE/rest";




@end
